<div>
    <div class="flex content-center h-36  bg-[url('/images/oficinas.jpg')] bg-center bg-no-repeat bg-fixed ">
        <?php echo e($slot); ?>

    </div>
</div><?php /**PATH C:\xampp\htdocs\gesccol-app\resources\views/components/header-bar.blade.php ENDPATH**/ ?>