

<?php $__env->startSection('title', 'Tramite | ' . $service->title); ?>
    
<?php $__env->startSection('content'); ?>

<section class="container m-auto mt-20">
    <header class=" px-20">
        <h1 class="text-4xl font-semibold mt-5 text-center"><?php echo $service->title; ?></h1>
        <p class=" text-xl my-5 "><?php echo $service->description; ?></p>
    </header>
    <div class="timeline mt-10 px-20">
        <?php echo $service->content; ?>

    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gesccol-app\resources\views/servicios/show.blade.php ENDPATH**/ ?>