

<?php $__env->startSection('title', 'Tramites Y Servicios | Gesccol'); ?>
    
<?php $__env->startSection('content'); ?>

<header class="container-xl">
    <?php if (isset($component)) { $__componentOriginal2fcc28dc7a552f9edde363af3520cce12c60da1c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\HeaderBar::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('header-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\HeaderBar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <h1 class="text-4xl text-black m-auto text-center font-semibold">Tramites y Servicios</h1>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2fcc28dc7a552f9edde363af3520cce12c60da1c)): ?>
<?php $component = $__componentOriginal2fcc28dc7a552f9edde363af3520cce12c60da1c; ?>
<?php unset($__componentOriginal2fcc28dc7a552f9edde363af3520cce12c60da1c); ?>
<?php endif; ?>  
</header>

<section class="container m-auto h-auto py-5">
    <div class="header w-full h-32 flex flex-col text-center content-center">
        <h1 class=" text-4xl font-bold text-primary m-auto">Tramites</h1>
        <h2 class="text-2xl font-bold text-primary m-auto">Conoce los requisitos para tramite</h2>
    </div>

    
    <div class="m-auto grid md:grid-cols-4 sm:grid-cols-3 grid-cols-1 gap-3 md:p-0 p-5 ">
        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="w-full h-64 bg-gray-300">
            <div class="w-full h-4/5  flex justify-center items-center text-center bg-btn">
                <h1 class=" text-2xl text-white font-medium"><?php echo e($service->title); ?></h1>
            </div>
            <div class="w-full h-auto flex justify-center items-center text-center">
                <a href="<?php echo e(route('servicios.show', $service)); ?>" class="m-1 w-32 p-2 bg-btn rounded-md text-white">requisitos</a>
            </div>   
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gesccol-app\resources\views/servicios/index.blade.php ENDPATH**/ ?>