<div class="form-group">
	<?php echo Form::label('title', 'nombre'); ?>

	<?php echo Form::text('title', null, ['class' => 'form-control', 'placeholder' => 'ingrese el nombre del servicio']); ?>


	<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	<small class="text-danger"><?php echo e($message); ?></small>
	<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group">
	<?php echo Form::label('slug', 'slug'); ?>

	<?php echo Form::text('slug', null, ['class' => 'form-control', 'placeholder' => 'ingrese el nombre del slug', 'readonly']); ?>


	<?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	<small class="text-danger"><?php echo e($message); ?></small>
	<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group">
		<?php echo Form::label('description', 'descripcion'); ?>

		<?php echo Form::textarea('description', null, ['class' => 'form-control']); ?>

		<?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
		<small class="text-danger"><?php echo e($message); ?></small>
		<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>


<div class="form-group">
		<?php echo Form::label('content', 'contenido'); ?>

		<?php echo Form::textarea('content', null, ['class' => 'form-control']); ?>

		<?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
		<small class="text-danger"><?php echo e($message); ?></small>
		<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div><?php /**PATH C:\xampp\htdocs\gesccol-app\resources\views/admin/servicios/partials/formservice.blade.php ENDPATH**/ ?>