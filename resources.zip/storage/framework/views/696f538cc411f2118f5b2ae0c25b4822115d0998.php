

<?php $__env->startSection('title', 'servicios | Gesccol'); ?>

<?php $__env->startSection('content_header'); ?>
     <a href="" class="btn btn-secondary float-right">Nuevo Servicio/Tramite</a>

    <h1>Listado de Servicios y Tramites</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <hr class="mt-5">

    <?php if(session('info')): ?>
        <?php if (isset($component)) { $__componentOriginal08391688e03353529fc1a5ef6a24130dfd496ae4 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\Alert::class, ['theme' => 'success','title' => 'Listo!!','dismissable' => true] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\Alert::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <strong><?php echo e(session('info')); ?></strong>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal08391688e03353529fc1a5ef6a24130dfd496ae4)): ?>
<?php $component = $__componentOriginal08391688e03353529fc1a5ef6a24130dfd496ae4; ?>
<?php unset($__componentOriginal08391688e03353529fc1a5ef6a24130dfd496ae4); ?>
<?php endif; ?>
    <?php endif; ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.service-list')->html();
} elseif ($_instance->childHasBeenRendered('ib921sX')) {
    $componentId = $_instance->getRenderedChildComponentId('ib921sX');
    $componentTag = $_instance->getRenderedChildComponentTagName('ib921sX');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ib921sX');
} else {
    $response = \Livewire\Livewire::mount('admin.service-list');
    $html = $response->html();
    $_instance->logRenderedChild('ib921sX', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gesccol-app\resources\views/admin/servicios/index.blade.php ENDPATH**/ ?>