<div>
    
    <section class="container m-auto text-center">
        <h1 class=" text-3xl my-6">Categorias</h1>
        <div class="flex flex-row flex-wrap justify-center w-auto">
            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('posts.categoria', $category)); ?>" class="p-4  block  w-35 mx-2 my-2 rounded-md bg-gray-200 text-center hover:bg-gray-300"><?php echo e($category->name); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>

</div><?php /**PATH C:\xampp\htdocs\gesccol-app\resources\views/components/categories.blade.php ENDPATH**/ ?>