<div>
    <div class="grid grid-cols-1 gap-6 md:grid-cols-3 h-auto py-6">
        <article class="shadow-2xl">
             <div class="w-full">
                 <img src="images/banner-notice.jpeg" alt="" class="w-full">
             </div>
             <div class="w-full p-3 text-[#2299AA] text-xl font-medium hover:underline">
                 <a href=""><h1>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Laborum, excepturi.</h1></a>
             </div>
        </article>
        <article class="shadow-2xl">
             <div class="w-full">
                 <img src="images/banner-notice.jpeg" alt="" class="w-full">
             </div>
             <div class="w-full p-3 text-[#2299AA] text-xl font-medium hover:underline">
                 <a href="shadow-2xl"><h1>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Laborum, excepturi.</h1></a>
             </div>
         </article>
         <article class="shadow-2xl">
             <div class="w-full">
                 <img src="images/banner-notice.jpeg" alt="" class="w-full">
             </div>
             <div class="w-full p-3 text-[#2299AA] text-xl font-medium hover:underline">
                 <a href=""><h1>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Laborum, excepturi.</h1></a>
             </div>
         </article>
     </div>
</div><?php /**PATH C:\xampp\htdocs\gesccol-app\resources\views/components/cards-notice.blade.php ENDPATH**/ ?>