

<?php $__env->startSection('title', 'Normativas | Gesccol'); ?>
    
<?php $__env->startSection('content'); ?>

<header class="container-xl">
    <?php if (isset($component)) { $__componentOriginal2fcc28dc7a552f9edde363af3520cce12c60da1c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\HeaderBar::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('header-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\HeaderBar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <h1 class="text-4xl text-white m-auto text-center">Normativas y Legalidades</h1>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2fcc28dc7a552f9edde363af3520cce12c60da1c)): ?>
<?php $component = $__componentOriginal2fcc28dc7a552f9edde363af3520cce12c60da1c; ?>
<?php unset($__componentOriginal2fcc28dc7a552f9edde363af3520cce12c60da1c); ?>
<?php endif; ?> 
</header>

<div class="content p-5 my-3 mx-3">
    <div x-data="{ openedIndex: 1 }" class="flex flex-col p-4">

        
        
        <div @click="openedIndex == 1 ? openedIndex = -1 : openedIndex = 1" class="mb-5 flex items-center bg-[#BED3F9] border-t border-b border-secondary p-4">
          <p class="text-xl">Decretos</p>
          <span :class="openedIndex == 1 ? 'fa-chevron-down' : 'fa-chevron-up'" class="fas ml-3"></span>
        </div>

        <div x-show.transition.in.duration.800ms="openedIndex == 1" class="border p-4 mb-5  ">
         <strong>Catastro:</strong>
         <p>es un registro administrativo en el que se incluyen todos los bienes inmuebles rústicos, urbanos y de características especiales de un territorio. Es decir, es una especie de inventario estatal de todos los inmuebles</p>
         <strong>Catastro:</strong>
         <p>es un registro administrativo en el que se incluyen todos los bienes inmuebles rústicos, urbanos y de características especiales de un territorio. Es decir, es una especie de inventario estatal de todos los inmuebles</p>
        </div>

        

        <div @click="openedIndex == 2 ? openedIndex = -1 : openedIndex = 2" class="mb-5 flex items-center bg-[#BED3F9] border-t border-b border-secondary p-4">
            <p class="text-xl">Decretos</p>
          <span :class="openedIndex == 2 ? 'fa-chevron-down' : 'fa-chevron-up'" class="fas ml-3"></span>
        </div>
          <div x-show.transition.in.duration.800ms="openedIndex == 2" class="border p-4 mb-5 ">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam varius vel magna lacinia mollis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Quisque ligula neque, imperdiet nec est laoreet, pulvinar commodo odio. Vivamus eget eleifend libero. Fusce dolor nibh, porta eu gravida ut, maximus non erat.
        </div>

          

        <div @click="openedIndex == 3 ? openedIndex = -1 : openedIndex = 3" class="mb-5 flex items-center bg-[#BED3F9] border-t border-b border-secondary p-4">
            <p class="text-xl">Decretos</p>
          <span :class="openedIndex == 3 ? 'fa-chevron-down' : 'fa-chevron-up'" class="fas ml-3"></span>
        </div>
          <div x-show.transition.in.duration.800ms="openedIndex == 3" class="border p-4 mb-5 ">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam varius vel magna lacinia mollis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Quisque ligula neque, imperdiet nec est laoreet, pulvinar commodo odio. Vivamus eget eleifend libero. Fusce dolor nibh, porta eu gravida ut, maximus non erat.
        </div>

          
          <div @click="openedIndex == 4 ? openedIndex = -1 : openedIndex = 4" class="mb-5 flex items-center bg-[#BED3F9] border-t border-b border-secondary p-4">
            <p class="text-xl">Decretos</p>
          <span :class="openedIndex == 4 ? 'fa-chevron-down' : 'fa-chevron-up'" class="fas ml-3"></span>
        </div>
          <div x-show.transition.in.duration.800ms="openedIndex == 4" class="border p-4 mb-5 ">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam varius vel magna lacinia mollis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Quisque ligula neque, imperdiet nec est laoreet, pulvinar commodo odio. Vivamus eget eleifend libero. Fusce dolor nibh, porta eu gravida ut, maximus non erat.
        </div>

        
        <div @click="openedIndex == 5 ? openedIndex = -1 : openedIndex = 5" class="mb-5 flex items-center bg-[#BED3F9] border-t border-b border-secondary p-4">
            <p class="text-xl">Decretos</p>
          <span :class="openedIndex == 5 ? 'fa-chevron-down' : 'fa-chevron-up'" class="fas ml-3"></span>
        </div>
          <div x-show.transition.in.duration.800ms="openedIndex == 5" class="border p-4 mb-5 ">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam varius vel magna lacinia mollis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Quisque ligula neque, imperdiet nec est laoreet, pulvinar commodo odio. Vivamus eget eleifend libero. Fusce dolor nibh, porta eu gravida ut, maximus non erat.
        </div>

        
        <div @click="openedIndex == 6 ? openedIndex = -1 : openedIndex = 6" class="mb-5 flex items-center bg-[#BED3F9] border-t border-b border-secondary p-4">
            <p class="text-xl">Decretos</p>
          <span :class="openedIndex == 6 ? 'fa-chevron-down' : 'fa-chevron-up'" class="fas ml-3"></span>
        </div>
          <div x-show.transition.in.duration.800ms="openedIndex == 6" class="border p-4 mb-5 ">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam varius vel magna lacinia mollis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Quisque ligula neque, imperdiet nec est laoreet, pulvinar commodo odio. Vivamus eget eleifend libero. Fusce dolor nibh, porta eu gravida ut, maximus non erat.
        </div>
      </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gesccol-app\resources\views/home/normativas.blade.php ENDPATH**/ ?>