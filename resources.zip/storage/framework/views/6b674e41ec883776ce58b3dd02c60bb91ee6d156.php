

<?php $__env->startSection('title', 'Noticia | ' . $post->title); ?>
    
<?php $__env->startSection('content'); ?>

<section class="container m-auto px-14">
      <div class="title w-full my-10 ">
        <h1 class=" text-4xl text-primary"><?php echo e($post->title); ?></h1>
     </div>
     
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div class="col-span-2">
          
            <div class="image  h-auto overflow-hidden w-full">
                <img src="<?php echo e(asset('images/banner-notice.jpeg')); ?>" alt="" class="object-cover object-center w-full">
            </div>
            <div class="contenido m-auto p-5 md:px-2 md:pt-5">
                <p class=" text-xl text-black">
                    <?php echo $post->content; ?>

                </p>
                <p class=" text-2xl mt-20 text-gray-600">Publicado por: <?php echo $post->author; ?></p>
            </div>
        </div>
        <div class="flex">
        <p>hola</p>
        </div>
    </div>
  
</section>


<section class="container m-auto mb-14">
    <h1 class="text-2xl my-10">Otras entradas relacionadas con la categoria <strong><?php echo e($post->category->name); ?></strong></h1>
    <div class="grid md:grid-cols-3 sm:grid-cols-2 grid-cols-1 gap-3 p-5">
        <?php $__currentLoopData = $similares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $similar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="bg-gray-200 h-80">
            <div class="w-auto">
                <img src="<?php echo e(asset('images/banner-notice.jpeg')); ?>" alt="">
            </div>
            <div class="w-auto p-5">
                <a href="<?php echo e(route('posts.show', $similar)); ?>" class="text-xl text-primary"><?php echo e($similar->title); ?></a>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gesccol-app\resources\views/posts/show.blade.php ENDPATH**/ ?>