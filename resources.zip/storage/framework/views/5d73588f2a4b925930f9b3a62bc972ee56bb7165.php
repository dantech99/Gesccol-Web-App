

<?php $__env->startSection('title', 'Editando Publicacion | Gesccol'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Editor de Publicaciones</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if (isset($component)) { $__componentOriginalac09df57349bd019565ada4b240c9ec027a8956f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Head\TinymceConfig::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('head.tinymce-config'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Head\TinymceConfig::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalac09df57349bd019565ada4b240c9ec027a8956f)): ?>
<?php $component = $__componentOriginalac09df57349bd019565ada4b240c9ec027a8956f; ?>
<?php unset($__componentOriginalac09df57349bd019565ada4b240c9ec027a8956f); ?>
<?php endif; ?>
 <?php if(session('info')): ?>
        
        <?php if (isset($component)) { $__componentOriginal08391688e03353529fc1a5ef6a24130dfd496ae4 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\Alert::class, ['theme' => 'success','title' => 'Listo!!','dismissable' => true] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\Alert::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <strong><?php echo e(session('info')); ?></strong>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal08391688e03353529fc1a5ef6a24130dfd496ae4)): ?>
<?php $component = $__componentOriginal08391688e03353529fc1a5ef6a24130dfd496ae4; ?>
<?php unset($__componentOriginal08391688e03353529fc1a5ef6a24130dfd496ae4); ?>
<?php endif; ?>
    <?php endif; ?>

<div class="card">
    <div class="card-body">
        <?php echo Form::model($post, ['route' => ['admin.posts.update', $post], 'autocomplete' => 'off', 'files' => true, 'method' => 'PUT']); ?>


        <?php echo $__env->make('admin.posts.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo Form::submit('Actualizar publicacion', ['class' => 'btn btn-primary']); ?>


        <?php echo Form::close(); ?>

    </div>
</div>
   


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .image-wrapper{
            position: relative;
            padding-bottom: 56.25%;
        }
        .image-wrapper img{
            position: absolute;
            object-fit: cover;
            width: 100%;
            height: 100%;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
   <script src="<?php echo e(asset('vendor/jQuery-Plugin-stringToSlug-1.3/jquery.stringToSlug.min.js')); ?>"></script>
    <script>
         $(document).ready( function() {
        $("#title").stringToSlug({
            setEvents: 'keyup keydown blur',
            getPut: '#slug',
            space: '-'
        });
        });

     

        //CAMBIAR IMAGEN Y MOSTRAR VISTA PREVIA
        document.getElementById("file").addEventListener('change', cambiarImagen);

        function cambiarImagen(event){
            let file = event.target.files[0];

            let reader = new FileReader();
            reader.onload = (event) =>{
                document.getElementById("picture").setAttribute('src', event.target.result);
            }
            reader.readAsDataURL(file);
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gesccol-app\resources\views/admin/posts/edit.blade.php ENDPATH**/ ?>