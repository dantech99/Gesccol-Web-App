<div class="card">
    <div class="card-header">
        buscador
    </div>

   <div class="card-body">
       <table class="table table-striped">
           <thead>
               <tr>
                   <th>id</th>
                   <th>title</th>
                   <th colspan="1">Acciones</th>
               </tr>
           </thead>
           <tbody>
               <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tr>
                   <td><?php echo e($service->id); ?></td>
                   <td><?php echo e($service->title); ?></td>
                   <td>
                       <a href="<?php echo e(route('admin.servicios.edit', $service)); ?>" class="btn btn-primary">Editar</a>
                   </td>
                   <td>
                       <form action="<?php echo e(route('admin.servicios.destroy', $service)); ?>" method="POST">
                           <?php echo method_field('DELETE'); ?>
                           <?php echo csrf_field(); ?>
                           <button class="btn btn-danger" type="submit">Eliminar</button>
                       </form>
                   </td>
               </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </tbody>
       </table>
   </div>
   
</div>
<?php /**PATH C:\xampp\htdocs\gesccol-app\resources\views/livewire/admin/service-list.blade.php ENDPATH**/ ?>