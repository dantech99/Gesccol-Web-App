

<?php $__env->startSection('title', 'Noticias Y Comunicados | Gesccol'); ?>
    
<?php $__env->startSection('content'); ?>     
<header class="container-xl">
    <?php if (isset($component)) { $__componentOriginal2fcc28dc7a552f9edde363af3520cce12c60da1c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\HeaderBar::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('header-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\HeaderBar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <h1 class="text-4xl text-white m-auto text-center font-semibold">Noticias, Informes y comunicados</h1>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2fcc28dc7a552f9edde363af3520cce12c60da1c)): ?>
<?php $component = $__componentOriginal2fcc28dc7a552f9edde363af3520cce12c60da1c; ?>
<?php unset($__componentOriginal2fcc28dc7a552f9edde363af3520cce12c60da1c); ?>
<?php endif; ?>  
</header>



<?php if (isset($component)) { $__componentOriginal18c84cce4a0aa799358027651cc2fcff0a147f1d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Categories::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('categories'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Categories::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal18c84cce4a0aa799358027651cc2fcff0a147f1d)): ?>
<?php $component = $__componentOriginal18c84cce4a0aa799358027651cc2fcff0a147f1d; ?>
<?php unset($__componentOriginal18c84cce4a0aa799358027651cc2fcff0a147f1d); ?>
<?php endif; ?>


<section class="container m-auto">
    <div class="container w-full my-5">
        <h1 class="m-auto text-2xl font-bold text-[#2299AA]">Noticias Comunicados  e Informes</h1>
    </div>

    <div class="grid grid-cols-1 gap-6 md:grid-cols-3 h-auto py-6 px-5 md:px-0">
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <article class="h-96 max-h-96 ">
                <div class="w-full h-60 overflow-hidden">
                    <?php if($post->image): ?>
                        <img src="<?php echo e(Storage::url($post->image->url)); ?>" alt="" c class="h-full w-full object-cover">
                    <?php else: ?>
                     <img src="images/banner-notice.jpeg" alt=""  class="h-full w-full object-cover">
                    <?php endif; ?>
                   
                </div>
                <div class="w-full p-3 text-[#2299AA] text-2xl font-medium hover:underline">
                    <a href="<?php echo e(route('posts.show', $post)); ?>"><h1><?php echo e($post->title); ?></h1></a>
                </div>
        </article>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
    </div>
    <div class=" mt-6 px-6 py-6 flex justify-center container m-auto ">
        <?php echo e($posts->links()); ?>

    </div>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gesccol-app\resources\views/posts/index.blade.php ENDPATH**/ ?>