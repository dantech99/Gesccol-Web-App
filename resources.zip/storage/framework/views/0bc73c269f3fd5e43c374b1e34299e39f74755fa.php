

<?php $__env->startSection('title', 'Categorias | Gesccol'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Categorias</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php if(session('info')): ?>
        <?php if (isset($component)) { $__componentOriginal08391688e03353529fc1a5ef6a24130dfd496ae4 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\Alert::class, ['theme' => 'success','title' => 'Listo!!','dismissable' => true] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\Alert::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <strong><?php echo e(session('info')); ?></strong>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal08391688e03353529fc1a5ef6a24130dfd496ae4)): ?>
<?php $component = $__componentOriginal08391688e03353529fc1a5ef6a24130dfd496ae4; ?>
<?php unset($__componentOriginal08391688e03353529fc1a5ef6a24130dfd496ae4); ?>
<?php endif; ?>
    <?php endif; ?>
    
    <p class="container">Seccion de categorias, aqui podras encontrar todas las categorias creadas previamente y que se alojan en la base de datos, las categorias sirven para dividir las entradas y poder filtrarlas por estas mismas</p>

    <hr class="mt-5">

    <section class="card">
        <header class="my-3 card-header ">
            
            <h1>Listado de Categorias</h1>
            <a href="<?php echo e(route('admin.categorias.create')); ?>" class="btn btn-primary">Agregar Categorias</a>
        </header>

        
        <?php if($categorias->count()): ?>
        <main class="card-body">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>nombre</th>
                        <th colspan="2">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($category->id); ?></th>
                        <th><?php echo e($category->name); ?></th>
                        <th width="10">
                            <a href="<?php echo e(route('admin.categorias.edit', $category)); ?>" class="btn btn-primary">Editar</a>
                        </th>
                        <th width="10px">
                            <form action="<?php echo e(route('admin.categorias.destroy', $category)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="submit" class="btn btn-danger">
                                    Eliminar
                                </button>
                            </form>
                        </th>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </tbody>
            </table>
        </main>
        <?php else: ?>
        <div class="card-body">
            <strong class="p-3">No hay registros para mostrar</strong>
        </div>
         <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gesccol-app\resources\views/admin/categorias/index.blade.php ENDPATH**/ ?>