<div class="card">
    <div class="card-header">
        <input wire:model="search" type="text" class="form-control" placeholder="ingrese registro a buscar">
    </div>

    <?php if($posts->count()): ?>
    <div class="card-body">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Titulo</th>
                    <th colspan="1">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                    <td><?php echo e($post->id); ?></td>
                    <td><?php echo e($post->title); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.posts.edit', $post)); ?>" class="btn btn-primary">Editar</a>
                    </td>
                    <td width="10px">
                        <form action="<?php echo e(route('admin.posts.destroy', $post)); ?>" method="POST">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-danger" type="submit">
                                eliminar
                            </button>
                        </form>
                    </td>
                </tr>   
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </tbody>
        </table>
    </div>

    <div class="card-footer">
        <?php echo e($posts->links()); ?>

    </div>
    <?php else: ?>
    <div class="card-body">
        <strong class="p-3">
            no hay registros para mostrar
        </strong>
    </div>
   <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\gesccol-app\resources\views/livewire/admin/post-list.blade.php ENDPATH**/ ?>