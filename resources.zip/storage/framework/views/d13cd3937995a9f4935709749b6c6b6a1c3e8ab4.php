

<?php $__env->startSection('title', 'Quienes Somos | Gesccol'); ?>
    
<?php $__env->startSection('content'); ?>

<header>
    <?php if (isset($component)) { $__componentOriginal2fcc28dc7a552f9edde363af3520cce12c60da1c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\HeaderBar::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('header-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\HeaderBar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <h1 class="text-4xl text-white m-auto text-center font-semibold">¿Quienes Somos?</h1>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2fcc28dc7a552f9edde363af3520cce12c60da1c)): ?>
<?php $component = $__componentOriginal2fcc28dc7a552f9edde363af3520cce12c60da1c; ?>
<?php unset($__componentOriginal2fcc28dc7a552f9edde363af3520cce12c60da1c); ?>
<?php endif; ?>
</header>

<section class="container m-auto h-auto my-10">
    <div class="grid md:grid-cols-4 grid-cols-1 gap-6">
        
        <div class="container w-full col-span-3">
            <div class="flex bg-blue-700 h-10">
                <h1 class="m-auto ml-5 text-white text-xl font-medium">Quienes Somos</h1>
            </div>
            <div class="container h-auto mt-5">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Odit reprehenderit sit vero neque id exercitationem, itaque, quas totam natus porro rerum dolorum. Qui corporis debitis maiores autem atque fugit provident dolores placeat iusto ducimus laudantium perspiciatis officia ipsum neque, ipsa repellendus praesentium. Temporibus rem quis enim eaque facilis ratione nemo fugiat consequuntur autem, vitae dolores perspiciatis, veniam explicabo aperiam placeat doloremque in. Culpa magni, fugiat recusandae maxime eos aperiam commodi quasi quibusdam cum nobis exercitationem aut. Similique delectus perferendis expedita soluta eius nihil porro repellendus esse impedit, dicta ipsa reiciendis aliquid blanditiis at aliquam! Sapiente temporibus est suscipit quasi perferendis.</p>
            </div>
        </div>

        
        <aside class="w-full  border border-gray-300 p-5">
            
        </aside>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gesccol-app\resources\views/home/quienes-somos.blade.php ENDPATH**/ ?>