

<?php $__env->startSection('title', 'Noticias | Gesccol'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Editor de Servicios</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   
<?php if (isset($component)) { $__componentOriginalac09df57349bd019565ada4b240c9ec027a8956f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Head\TinymceConfig::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('head.tinymce-config'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Head\TinymceConfig::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalac09df57349bd019565ada4b240c9ec027a8956f)): ?>
<?php $component = $__componentOriginalac09df57349bd019565ada4b240c9ec027a8956f; ?>
<?php unset($__componentOriginalac09df57349bd019565ada4b240c9ec027a8956f); ?>
<?php endif; ?>

<?php if(session('info')): ?>
    <?php if (isset($component)) { $__componentOriginal08391688e03353529fc1a5ef6a24130dfd496ae4 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\Alert::class, ['theme' => 'success','title' => 'Listo!!','dismissable' => true] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\Alert::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <strong><?php echo e(session('info')); ?></strong>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal08391688e03353529fc1a5ef6a24130dfd496ae4)): ?>
<?php $component = $__componentOriginal08391688e03353529fc1a5ef6a24130dfd496ae4; ?>
<?php unset($__componentOriginal08391688e03353529fc1a5ef6a24130dfd496ae4); ?>
<?php endif; ?>
<?php endif; ?>


<div class="card">
    <div class="card-body">
        <?php echo Form::model($service, ['route' => ['admin.servicios.update', $service], 'autocomplete' => 'off','method' => 'PUT']); ?>


        <?php echo $__env->make('admin.servicios.partials.formservice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo Form::submit('Actualizar servicio', ['class' => 'btn btn-primary']); ?>


        <?php echo Form::close(); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gesccol-app\resources\views/admin/servicios/edit.blade.php ENDPATH**/ ?>