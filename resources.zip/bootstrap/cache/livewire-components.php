<?php return array (
  'admin.post-list' => 'App\\Http\\Livewire\\Admin\\PostList',
  'admin.service-list' => 'App\\Http\\Livewire\\Admin\\ServiceList',
  'navigation' => 'App\\Http\\Livewire\\Navigation',
);