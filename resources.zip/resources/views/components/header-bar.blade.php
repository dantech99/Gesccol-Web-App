<div>
    <div class="flex content-center h-36  bg-[url('/images/oficinas.jpg')] bg-center bg-no-repeat bg-fixed ">
        {{ $slot }}
    </div>
</div>