{{-- barra gov --}}
<div class="container-xl d-flex  h-10 bg-[#3366CC]">
   <div class="container flex m-auto h-full">
    <img class=" w-auto my-2" src="{{ asset('images/logo.png') }}" alt="">
   </div>
</div>

{{-- contendor del logo empresarial --}}
<div class="container m-auto">
<div class=" grid grid-cols-6 h-32 m-auto">
   <div class="flex align-items-center p-4 col-span-4">
      <a href="/" class="my-auto ml-5">
         <img src="{{ asset('images/logo-gesccol.png') }}" alt="" class=" w-80">
      </a>
   </div>
   <div class="m-auto md:flex align-items-center hidden ">
      <select name="idiomas" id="" class=" w-full h-7 m-auto border-2 border-gray-400 ">
         <option value="value2" selected>Select Lenguaje</option>
         <option value="1" class="p-3">español</option>
         <option value="1" class="p-3">español</option>
         <option value="1" class="p-3">español</option>
      </select>
      <span class="m-auto ml-2">Idioma</span>
   </div>

   <div class="container md:flex hidden align-items-center ">
      <a href="" class="m-auto"><ion-icon name="logo-facebook"></ion-icon></a>
   </div>
</div>
</div>
